import os
import webbrowser
import sys


print('USERCHECK! Find where a username is being used! Type help for help, or type in a username!')

statement = input("").lower()

while True:
    if 'check' in statement:
        print('USERCHECK: Checking common sites for users...')
        statement =statement.replace("check ", "")
        webbrowser.open_new_tab('https://knowem.com/checkusernames.php?u={}'.format(statement))


    elif 'help' in statement:
        print("-----------------------------------------------------------------")
        print(" --- General Config ---")
        print("'check USERNAME': Searches most common sites for usernames in use")
        print("EX: check bobbert123")
        print('')
        print("'exit': Exits back to HackBox")
        print("-----------------------------------------------------------------")

        print("USERCHECK: Anyone else you wanna spy on?")
    elif statement == 'exit':   
        print('USERCHECK: Exiting USERCHECK')
        exec(open('HackBox.py').read()) 


        
        

    else:
        print('USERCHECK: Invalid Paramater, type help for help, or exit to exit')


    statement = input("").lower()



    ## maybe make this pop out on its own window - OR create a settings page taht the user can edit