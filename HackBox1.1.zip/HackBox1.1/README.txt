1) install python 3.8 (from windows store, it makes life easy)
2) run prereq.bat (double click) to install prereq's - ignore any red code
3) Open CMD/term as ADMIN, CD to file location and run 'python hackbox.py' -or else you may run into permissions denied issues, along with 'system cannot find path specified'


What Am I?
Hackbox is an interactive custom shell for whatever you need it to be. 
It can load in custom scripts, or or tools written in python (more to be added later)
You can run these individually, or use HackBox to access them faster.