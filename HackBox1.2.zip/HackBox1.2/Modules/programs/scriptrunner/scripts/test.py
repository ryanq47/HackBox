import os
print('hello there')
os.system('pause')