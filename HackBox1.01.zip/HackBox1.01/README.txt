1) install python 3.8 (from windows store, it makes life easy)
2) run prereq.bat (double click) to install prereq's - ignore any red code
3) Open CMD/term as ADMIN, CD to file location and run 'python hackbox.py' -or else you may run into permissions denied issues